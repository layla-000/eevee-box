window.EEVEE_BOX_CONFIG = {
  apiEndpoint: ""
};
